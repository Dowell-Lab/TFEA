mumerge_path='SET YOUR PATH HERE'
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+delta_mu_rep_test/delta_rep_test_mu0 -o 1000 -N 1000 -r 3 -a 0 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+delta_mu_rep_test/delta_rep_test_mu-025_025 -o 1000 -N 1000 -r 3 -a -25 100 0.5 100 -a 25 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+delta_mu_rep_test/delta_rep_test_mu-050_050 -o 1000 -N 1000 -r 3 -a -50 100 0.5 100 -a 50 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+delta_mu_rep_test/delta_rep_test_mu-075_075 -o 1000 -N 1000 -r 3 -a -75 100 0.5 100 -a 75 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+delta_mu_rep_test/delta_rep_test_mu-100_100 -o 1000 -N 1000 -r 3 -a -100 100 0.5 100 -a 100 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+delta_mu_rep_test/delta_rep_test_mu-125_125 -o 1000 -N 1000 -r 3 -a -125 100 0.5 100 -a 125 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+delta_mu_rep_test/delta_rep_test_mu-150_150 -o 1000 -N 1000 -r 3 -a -150 100 0.5 100 -a 150 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+delta_mu_rep_test/delta_rep_test_mu-175_175 -o 1000 -N 1000 -r 3 -a -175 100 0.5 100 -a 175 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+delta_mu_rep_test/delta_rep_test_mu-200_200 -o 1000 -N 1000 -r 3 -a -200 100 0.5 100 -a 200 100 0.5 100
