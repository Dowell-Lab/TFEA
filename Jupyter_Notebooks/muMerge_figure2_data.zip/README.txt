Author: Jacob T. Stanley
Email: jacob.stanley@colorado.edu
Uploaded: 6/2020

Install: Unzip the contents of this file to the same directory. In order to run the jupyter notebook, set the `root` variable in the notebook to the directory to which you extracted the files.


