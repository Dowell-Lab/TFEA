mumerge_path='SET YOUR PATH HERE'
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+rep_test/rep_test_mu0_R02 -o 1000 -N 10000 -r 2 -a 0 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+rep_test/rep_test_mu0_R03 -o 1000 -N 10000 -r 3 -a 0 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+rep_test/rep_test_mu0_R04 -o 1000 -N 10000 -r 4 -a 0 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+rep_test/rep_test_mu0_R05 -o 1000 -N 10000 -r 5 -a 0 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+rep_test/rep_test_mu0_R06 -o 1000 -N 10000 -r 6 -a 0 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+rep_test/rep_test_mu0_R07 -o 1000 -N 10000 -r 7 -a 0 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+rep_test/rep_test_mu0_R08 -o 1000 -N 10000 -r 8 -a 0 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+rep_test/rep_test_mu0_R09 -o 1000 -N 10000 -r 9 -a 0 100 0.5 100
python3 ${mumerge_path}+mumerge_test_unit.py -f ${mumerge_path}+rep_test/rep_test_mu0_R10 -o 1000 -N 10000 -r 10 -a 0 100 0.5 100
